package controller.tab;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class CreateTableController {
	@FXML private Button CTcreatetableBT;
	@FXML private Button CTsubmitBT;
	
@FXML private void CTcreatetableBTClicked(ActionEvent event){
		System.out.print("working");
	}
	
@FXML private void CTsubmitBTClicked(ActionEvent event){
	System.out.print("working");
	}
}
